function useState(inital) {
  return [inital,function(val){
    console.log("state is "+val);
  }];
}
const [state,setState] = useState(0);
console.log(state,setState)